﻿using System.Collections.Generic;

namespace Rondinelli.MyHouseFinance.Application.ViewModels.Relatorios
{
    public class RelatorioDespesasViewModel
    {
        public List<string> Labels { get; set; }
        public List<decimal> Valor { get; set; }


    }
}